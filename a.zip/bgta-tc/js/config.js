window.ENV = window.ENV || {};
window.ENV.mode = 'WEB';
window.ENV.validateBrowser = true;
window.ENV.production = 'production';

window.ENV.tcApp = 'https://tcdigital.bancodebogota.com/web-card/info-motor/';
window.ENV.rnec = 'https://authenticatorweb.bancodebogota.com.co/';
window.ENV.apiEndpointEvents = 'https://api.bancodebogota.co/event/';
window.ENV.rnecEndpoint = 'https://api.bancodebogota.co/auth/';
window.ENV.container = 'GTM-N5DKC46';
